var express = require('express');
var router = express.Router();

var fileUpLoadDao = require('../dao/fileUpLoadDao');

router.post('/fileUpLoad', function(req, res, next) {
    console.log(req)
    fileUpLoadDao.fileUpLoad(req, res, next);
});

module.exports = router;