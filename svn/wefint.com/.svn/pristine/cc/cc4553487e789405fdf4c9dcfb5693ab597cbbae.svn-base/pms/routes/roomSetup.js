var express = require('express');
var router = express.Router();

var roomSetupDao = require('../dao/roomSetupDao');

/* GET home page. */
router.get('/', function(req, res, next) {
    res.send('respond with a resource');
});
router.post('/queryAllByUserName', function(req, res, next) {
    console.log(req.body)
    roomSetupDao.queryAllByUserName(req.body, res, next);
});
router.post('/deleteByRoomNumber', function(req, res, next) {
    console.log(req.body)
    roomSetupDao.deleteByRoomNumber(req.body, res, next);
});
router.post('/addRoom', function(req, res, next) {
    console.log(req.body)
    roomSetupDao.addRoom(req.body, res, next);
});
module.exports = router;