var express = require('express');
var router = express.Router();

var userLoginDao = require('../dao/userLoginDao');

/* GET home page. */
router.get('/', function(req, res, next) {
    res.send('respond with a resource');
});
router.post('/queryByNameAndPassword', function(req, res, next) {
    // console.log(req.body)
    userLoginDao.queryByNameAndPassword(req.body, res, next);
});
router.post('/add', function(req, res, next) {
    console.log(req.body)
    userLoginDao.add(req.body, res, next);
});
module.exports = router;