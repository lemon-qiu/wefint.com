var express = require('express');
var router = express.Router();

var roomStatusDao = require('../dao/roomStatusDao');

/* GET home page. */
router.get('/', function(req, res, next) {
    res.send('respond with a resource');
});
router.post('/queryByDateQuantum', function(req, res, next) {
    console.log(req.body)
    roomStatusDao.queryByDateQuantum(req.body, res, next);
});
router.post('/add', function(req, res, next) {
    console.log(req.body)
        // roomStatusDao.add(req.body, res, next);
});
module.exports = router;