// dao/userDao.js
// 实现与MySQL交互
var mysql = require('mysql');
var $conf = require('../conf/db');
var $util = require('../util/util');
var $sql = require('./roomStatusSqlMapping');
var generateUUID = require('../util/generateUUID');

// 使用连接池，提升性能
var pool = mysql.createPool($util.extend({}, $conf.mysql));

// 向前台返回JSON方法的简单封装
var jsonWrite = function(res, ret) {
    console.log(ret)
        //  ret = 'undefined'
    if (typeof ret === 'undefined') {
        res.json({
            code: '1',
            msg: '操作失败'
        });
    } else {
        res.send(JSON.stringify(ret));
    }
};

module.exports = {
    add: function(req, res, next) {
        pool.getConnection(function(err, connection) {
            console.log(req)
                // 获取前台页面传过来的参数
            var userName = "" + req.userName; // 为了拼凑正确的sql语句，这里要转下整数
            var password = "" + req.password; // 为了拼凑正确的sql语句，这里要转下整数
            var roomNumber = "" + req.roomNumber; // 为了拼凑正确的sql语句，这里要转下整数
            var startDay = "" + req.startDay; // 为了拼凑正确的sql语句，这里要转下整数
            var clientType = "" + req.clientType; // 为了拼凑正确的sql语句，这里要转下整数
            var cilentName = "" + req.cilentName; // 为了拼凑正确的sql语句，这里要转下整数
            var clientCellNumber = "" + req.clientCellNumber; // 为了拼凑正确的sql语句，这里要转下整数
            var idCardNumber = "" + req.idCardNumber; // 为了拼凑正确的sql语句，这里要转下整数
            var clientSource = "" + req.clientSource; // 为了拼凑正确的sql语句，这里要转下整数
            var stayDays = "" + req.stayDays; // 为了拼凑正确的sql语句，这里要转下整数
            var truePayment = "" + req.truePayment; // 为了拼凑正确的sql语句，这里要转下整数
            var paymentWays = "" + req.paymentWays; // 为了拼凑正确的sql语句，这里要转下整数
            var note = "" + req.note; // 为了拼凑正确的sql语句，这里要转下整数

            // userName 账号
            // "userName": getCookie('userName'),
            //     // password 密码
            //     "password": getCookie('password'),
            //     // clientType 预定 / 现住
            //     "clientType": data.clientType,
            //     // cilentName 入住人姓名
            //     "cilentName": data.cilentName,
            //     // clientCellNumber 入住人手机
            //     "clientCellNumber": data.clientCellNumber,
            //     // idCardNumber 身份证号
            //     "idCardNumber": data.idCardNumber,
            //     // clientSource 客人来源 飞猪 艺龙
            //     "clientSource": data.clientSource,
            //     // "startDay": data.startDay, //开始入住日
            //     "startDay": getCookie("Date"), //开始入住日
            //     // stayDays 住宿天数（ 几天几条数据） 3
            //     "stayDays": data.stayDays,
            //     // enterRoomPrice 输入房间价格
            //     "enterRoomPrice": data.enterRoomPrice,
            //     // truePayment 实际收款（ 前台输入）
            //     "truePayment": data.getPrice,
            //     // paymentWays 收费选项付款方式 - 现金， 刷卡， 微信， 支付宝， 其他
            //     "paymentWays": data.priceFrom,
            //     // note 备注
            //     "note": data.note,
            //     //房间编号
            //     "roomNumber": getCookie("roomNumber"),
            // roomNumber 房间编号（ 同一家客栈不重复） 同客栈唯一
            // 建立连接，向表中插入值
            // 'INSERT INTO user(id, name, age) VALUES(0,?,?)',
            connection.query($sql.check, [userName, password], function(err, result) {
                if (false) {
                    // if (result != "") {
                    console.log("UserNameIsExist");
                    if (result) {
                        result = {
                            code: "800",
                            msg: "用户名重复，请更换。"
                        };
                    }
                    // 以json形式，把操作结果返回给前台页面
                    jsonWrite(res, result);
                } else {
                    for (var i = 0; i < hasStayDate; i++)


                        console.log("UserNameIsNOTExist" + generateUUID());
                    connection.query($sql.addRoomStatus, [generateUUID(), copyId, roomId, clientType, cilentName, clientCellNumber, idCardNumber,
                        clientSource, startDay, stayDays, endDay, hasStayDate, enterRoomPrice,
                        truePayment, paymentWays, time, note, ifCanBeDeleted, isDeleted, isCancelledByNet,
                        userName, isUnsubscribe
                    ], function(err, result) {
                        if (result) {
                            result = {
                                code: "200",
                                msg: '注册成功'
                            };
                        }
                        // 以json形式，把操作结果返回给前台页面
                        jsonWrite(res, result);
                    });
                }
                //释放连接
                connection.release();
            });

        });
    },
    delete: function(req, res, next) {
        // delete by Id
        pool.getConnection(function(err, connection) {
            var id = +req.query.id;
            connection.query($sql.delete, id, function(err, result) {
                if (result.affectedRows > 0) {
                    result = {
                        code: 200,
                        msg: '删除成功'
                    };
                } else {
                    result = void 0;
                }
                jsonWrite(res, result);
                connection.release();
            });
        });
    },
    update: function(req, res, next) {
        // update by id
        // 为了简单，要求同时传name和age两个参数
        var param = req.body;
        if (param.name == null || param.age == null || param.id == null) {
            jsonWrite(res, undefined);
            return;
        }

        pool.getConnection(function(err, connection) {
            connection.query($sql.update, [param.name, param.age, +param.id], function(err, result) {
                // 使用页面进行跳转提示
                if (result.affectedRows > 0) {
                    res.render('suc', {
                        result: result
                    }); // 第二个参数可以直接在jade中使用
                } else {
                    res.render('fail', {
                        result: result
                    });
                }

                connection.release();
            });
        });

    },
    queryByDateQuantum: function(req, res, next) {
        //   console.log("queryByDateQuantum" + req.password);
        var userName = "" + req.userName; // 为了拼凑正确的sql语句，这里要转下整数
        var beginDate = "" + req.beginDate; // 为了拼凑正确的sql语句，这里要转下整数
        var endDate = "" + req.endDate; // 为了拼凑正确的sql语句，这里要转下整数
        var roomProperty = "";
        // console.log(beginDate + " " + endDate)
        // var userName = "username9"; // 为了拼凑正确的sql语句，这里要转下整数
        // var password = "password"; // 为了拼凑正确的sql语句，这里要转下整数
        pool.getConnection(function(err, connection) {
            connection.query('select * from pms_room where userName=?', [userName], function(err, result) {
                console.log("queryAllByUserName :" + result)
                roomProperty = result;

                connection.query($sql.queryByDateQuantum, [userName, beginDate, endDate], function(err, result) {
                    console.log("queryByDateQuantum :" + result)
                    if (result != "") {
                        result = {
                            code: "200",
                            roomProperty: roomProperty,
                            roomStatus: result,
                        };
                    } else {
                        result = {
                            code: "200",
                            roomProperty: roomProperty,
                            roomStatus: result,
                        };
                    }
                    jsonWrite(res, result);
                    connection.release();
                });
            });
        });
    },
    queryAll: function(req, res, next) {
        pool.getConnection(function(err, connection) {
            connection.query($sql.queryAll, function(err, result) {
                jsonWrite(res, result);
                connection.release();
            });
        });
    }

};