// dao/userSqlMapping.js
// CRUD SQL语句
var finance = {
    insertPage01: 'INSERT INTO pms_finance_page1 (id, userName, password, idCardNumber, phoneNumber,hotelName, hotelLocationDetails, isSubmited) VALUES(?,?,?,?,?,?,?,?)',
    insertPage02: 'INSERT INTO pms_finance_page2 (id, userName, password, email, car, companyCredit, education,profession, zhimaCredit, note, isSubmited) VALUES(?,?,?,?,?,?,?,?,?,?,?)',
    checkIsSubmitedPage01: 'select * from pms_finance_page1 where userName=? and password=?',
    checkIsSubmitedPage02: 'select * from pms_finance_page2 where userName=? and password=?',
};

module.exports = finance;