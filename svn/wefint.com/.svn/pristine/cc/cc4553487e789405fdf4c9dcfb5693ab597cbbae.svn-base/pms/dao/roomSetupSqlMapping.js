// dao/userSqlMapping.js
// CRUD SQL语句
var roomSetup = {
    insert: 'INSERT INTO pms_user_register(id,userName, password, hotelName,phoneNumber,email) VALUES(?,?,?,?,?,?)',
    update: 'update user set name=?, age=? where id=?',
    deleteByRoomNumber: 'delete from pms_room where userName=? and roomNumber=?',
    queryByDateQuantum: 'select * from pms_edit where userName=? and hasStayDate between ? and ?',
    queryAllByUserName: 'select * from pms_room where userName=?',
    checkIfUserNameIsExist: 'select * from pms_user_register where userName=?',
    checkIfRoomNumberIsExist: 'select * from pms_room where userName=? and roomNumber=?',
    insertRoom: 'INSERT INTO pms_room (userName,roomType,roomName,roomNumber,roomInitalPrice,roomSpecialDatePrice) VALUES(?,?,?,?,?,?)',
};

module.exports = roomSetup;