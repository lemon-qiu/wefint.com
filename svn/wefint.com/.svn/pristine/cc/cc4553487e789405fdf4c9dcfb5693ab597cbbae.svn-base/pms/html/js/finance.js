function submitToFinance(data) {
    if (false) {
        alert("图片需要先预览，以确定您上传的文件正确！")
    }
    $.ajax({
        cache: true,
        type: "POST",
        url: SERVER_ADD_PORT + "/finance/page01",
        data: {
            "userName": getCookie('userName'),
            "password": getCookie('password'),
            "idCardNumber": data.idCardNumber,
            //手机号
            "phoneNumber": data.phoneNumber,
            //客栈名称
            "hotelName": data.hotelName,
            //详细地址
            "hotelLocationDetails": data.hotelLocationDetails,
        },
        async: false,
        error: function(request) {
            alert("获取状态失败，请稍后");
        },
        success: function(data) {
            var obj = JSON.parse(data);
            if (obj.code == "200") {
                window.location.href = "./hexagram.html";
                // return false;
            }
        }
    });
    return false;
}



function d(data) {
    var aa;
    var JsonData = {
            "userName": getCookie('userName'),
            "password": getCookie('password'),
            //承租期
            "limitPic": data.limitPic,
            //身份证
            "idCardPicFront": data.idCardPicFront,
            "idCardBack": data.idCardBack,
            "idCardNumber": data.idCardNumber,
            //手机号
            "phoneNumber": data.phoneNumber,
            //客栈名称
            "hotelName": data.hotelName,
            //详细地址
            "hotelLocationDetails": data.hotelLocationDetails,
        }
        //alert(JSON.stringify(JsonData))
    $.ajax({
        cache: true,
        type: "POST",
        url: SERVER_ADD_PORT + "/fileUpLoad/fileUpLoad",
        data: {
            "strFinanceSetup": JSON.stringify(JsonData)
        },
        async: false,
        error: function(request) {
            alert("获取状态失败，请稍后");
        },
        success: function(data) {
            // alert(data)
            if ("405" == data) {
                alert("提交失败！");
                return false;
            }
            if (data == "200") {
                aa = data;
                // alert("正在审核,请耐心等待...");
                // setCookie('userName', encodeStr, 7);
                // setCookie('password', encodeStr1, 7)
                window.location.href = "./mainPannel.html";
                // return false;
            }
        }
    });
    return false;
}

function doValidate() {
    var phoneNumReg = /^1[3|4|5|7|8]\d{9}$/
    if (!phoneNumReg.test(document.forma.phoneNumber.value)) {
        alert('手机号码有误，请重填，手机号码11位数字，目前支持前两位13、14、15、16、17、18手机号码');
        document.forma.phoneNumber.focus();
        return false;
    }
    return true;
}

function applyMoney(data) {
    var bb = doValidate();
    alert(bb);
    var aa = d(data);
    alert(aa);

}

function uploadFile(n) {
    var formData = new FormData();
    switch (n) {
        case 0:
            var file = document.getElementById("LIMITPIC")
            if (file.files[0] == undefined) {
                alert("请选择文件");
                return false;
            }
            formData.append('file', file.files[0]);
            formData.append('fileType', "1");
            formData.append('fileClass', "LIMITPIC");
            break;
        case 1:
            var file = document.getElementById("IDCARDPICFRONT")
            if (file.files[0] == undefined) {
                alert("请选择文件");
                return false;
            }
            formData.append('file', file.files[0]);
            formData.append('fileType', "1");
            formData.append('fileClass', "IDCARDPICFRONT");
            break;
        case 2:
            var file = document.getElementById("IDCARDBACK")
            if (file.files[0] == undefined) {
                alert("请选择文件");
                return false;
            }
            formData.append('file', file.files[0]);
            formData.append('fileType', "1");
            formData.append('fileClass', "IDCARDBACK");
            break;
        default:
            break;
    }
    formData.append('userName', getCookie('userName'));
    formData.append('password', getCookie('password'));

    $.ajax({
        url: SERVER_ADD_PORT + "/fileUpLoad/fileUpLoad",
        type: 'POST',
        data: formData,
        // async: false,
        cache: false,
        contentType: false,
        processData: false,
        success: function(data) {
            // alert(data)
            var obj = JSON.parse(data);
            if ("200" == obj.code) {

                switch (n) {
                    case 0:
                        $('#result0').html("上传成功！");
                        $('#img0').attr('src', obj.msg);
                        break;
                    case 1:
                        $('#result1').html("上传成功！");
                        $('#img1').attr('src', obj.msg);
                        break;
                    case 2:
                        $('#result2').html("上传成功！");
                        $('#img2').attr('src', obj.msg);
                        break;
                    default:
                        break;
                }
            } else {
                switch (n) {
                    case 0:
                        $('#result0').html("上传成功！");
                        break;
                    case 1:
                        $('#result1').html("上传成功！");
                        break;
                    case 2:
                        $('#result2').html("上传成功！");
                        break;
                    default:
                        break;
                }
            }
            console.log('imgUploader upload success');
        },
        error: function() {
            $("#result").html("与服务器通信发生错误");
        }
    });
}

function postPage() {
    var uploada0 = document.getElementById('upload0');
    uploada0.addEventListener("click", function() {
        uploadFile(0);
    }, false);

    var uploada1 = document.getElementById('upload1');
    uploada1.addEventListener("click", function() {
        uploadFile(1);
    }, false);

    var uploada2 = document.getElementById('upload2');
    uploada2.addEventListener("click", function() {
        uploadFile(2);
    }, false);

    $.ajax({
        cache: true,
        type: "POST",
        url: SERVER_ADD_PORT + "/finance/checkPage01",
        data: {
            "userName": getCookie('userName'),
            "password": getCookie('password'),
        },
        async: false,
        error: function(request) {
            alert("获取状态失败，请稍后");
        },
        success: function(data) {
            alert(data)
            var obj = JSON.parse(data);
            if (obj.code == "600") {
                window.location.href = "./hexagram.html";
            }
        }
    });
}