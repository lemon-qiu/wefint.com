var code;

function createCode() {
    code = "";
    var codeLength = 4;
    var checkCode = document.getElementById("code");
    var random = new Array(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
        'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z');
    for (var i = 0; i < codeLength; i++) {
        var index = Math.floor(Math.random() * 36);
        code += random[index];
    }
    document.getElementById("code").value = code;
}

function validate() {

    var inputCode = document.getElementById("checkcode").value.toUpperCase();
    // alert("hhe" + inputCode);
    if (inputCode.length <= 0) {
        return false;
    } else if (inputCode != code) {
        alert("验证码错误!");
        createCode();
        document.getElementById("checkcode").value = "";
        return false;
    }
    return true;
}

function memberRegister(data) {

    var base = new Base64();
    var encodeStr = base.encode(data.userName);
    var encodeStr1 = base.encode(data.password);

    $.ajax({
        cache: true,
        type: "POST",
        url: "http://localhost:3000/userLogin/add",
        data: {
            "userName": encodeStr,
            "password": encodeStr1,
            "hotelName": data.hotelName,
            "phoneNumber": data.phoneNumber,
            "email": data.email,
        },
        async: false,
        error: function(request) {
            alert("注册失败，请稍后再试");
        },
        success: function(data) {
            alert(data);
            if (data == "405") {
                alert("内部错误，请稍后再试");
            }
            if (data == "800") {
                alert("用户名重复请更换！");
            }
            if (data == "200") {
                alert("注册成功请登陆");
                window.location.href = "../html/login.html";
            }
            return false;
        }
    });


}