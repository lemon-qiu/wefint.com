// var AllowImgFileSize = 256; //允许上传图片文件的大小 0为无限制 单位：KB  
// var AllowImgWidth = 600; //允许上传的图片的宽度 0为无限制　单位：px(像素) 
// var AllowImgHeight = 600; //允许上传的图片的高度 0为无限制　单位：px(像素)
// function checkImg() {
//     alert("111");
//     var txtImg = document.getElementById("txtImg");
//     alert(txtImg.value);
//     // if (txtImg.value == "") {
//     //     alert("请点击浏览按钮，选择您要上传的JPG或GIF文件!");
//     //     txtImg.focus();
//     //     return false;
//     // }

//     // var txtImg_url = txtImg.value.toLowerCase();
//     // var txtImg_ext = txtImg_url.substring(txtImg_url.length - 3, txtImg_url.length);
//     // if (txtImg_ext != "jpg" && txtImg_ext != "gif") {
//     //     alert("请选择JPG或GIF格式的文件!");
//     //     txtImg.select()
//     //     document.execCommand("Delete");
//     //     txtImg.focus();
//     //     return false;
//     // }
//     var ErrMsgErrMsg = ""; //错误信息
//     alert("ErrMsgErrMsg")
//     var img = new Image();
//     alert("here")
//     img.src = txtImg.value;
//     alert("here")
//     if (img.width > AllowImgWidth) {
//         alert("3333")
//         ErrMsgErrMsg = "\n\n图片宽度超过限制 请上传宽度小于" + AllowImgWidth + "px的文件，当前图片宽度为" + img.width + "px";
//         alert(ErrMsgErrMsg);
//         return false;
//     }
//     if (img.height > AllowImgWidth) {
//         ErrMsgErrMsg = "\n\n图片高度超过限制 请上传高度小于" + AllowImgHeight + "px的文件，当前图片高度为" + img.height + "px";
//         alert(ErrMsgErrMsg);
//         return false;
//     }

//     var size = formatNum(img.fileSize / 512, 2);
//     if (size > AllowImgFileSize) {
//         ErrMsgErrMsg = "\n\n图片文件大小超过限制 请上传小于" + AllowImgFileSize + "KB的文件，当前文件大小为" + size + "KB";
//         alert(ErrMsgErrMsg);
//         return false;
//     }
//     alert('ok!');
//     return true;
// }

// function formatNum(amt, pre) {
//     alert("222");
//     pre = pre > 0 && pre <= 20 ? pre : 2;

//     amt = parseFloat((amt + "").replace(/[^\d\.-]/g, "")).toFixed(pre) + "";
//     var left = amt.split(".")[0].split("").reverse();

//     var right = amt.split(".")[1];

//     var t = "";
//     for (i = 0; i < left.length; i++) {
//         t += left[i] + ((i + 1) % 3 == 0 && (i + 1) != left.length ? "" : "");
//     }
//     return t.split("").reverse().join("") + "." + right;
// }


function textFile(data) {


    var JsonData = {
        "userName": "MTExMTExMTExMTE=",
        "password": "MTExMTExMTExMTE=",
        //图片1
        "fileClass": "IDCARDPICFRONT",
        //文件2
        // "inputPath": data.inputPath,
        "inputPath": "C:/fakepath/banner-bg.jpg",
        // //字段1
        // "hotelName": data.hotelName,
        // //字段2
        // "hotelName1": data.hotelName1,
    }
    alert(JSON.stringify(JsonData))

    $.ajaxFileUpload({
        url: 'http://10.168.10.190:8080/HotelPMS/FinancialFrontSetUpServlet', // servlet请求路径  
        secureuri: false,
        fileElementId: 'txtImg', // 上传控件的id  
        dataType: 'json',
        data: {
            "strFinancialFrontSetUp": JSON.stringify(JsonData)
        }, // 其它请求参数  
        success: function(data, status) {
            alert(data + status);
            if (data.msg) {
                alert(data.msg);
            }
        },
        error: function(data, status, e) {
            alert('上传出错');
        }
    })

    return false;
    // $.ajax({
    //     cache: true,
    //     type: "POST",
    //     url: "http://10.168.10.190:8080/HotelPMS/FinancialFrontSetUpServlet",
    //     data: {
    //         "strFinancialFrontSetUp": JSON.stringify(JsonData)
    //     },
    //     async: false,
    //     error: function(request) {
    //         alert("获取状态失败，请稍后");
    //     },
    //     success: function(data) {
    //         alert(data)
    //         if ("405" == data) {
    //             alert("提交失败！");
    //             return false;
    //         }
    //         if (data == "200") {

    //             alert("成功！");
    //             return false;
    //         }
    //     }
    // });
    // return false;
}