//点击按钮查看报表
//获取客栈名称
function getName() {
    var JsonData = {
            "userName": getCookie('userName'),
            "password": getCookie('password'),
            //    "userName": "998",
            //    "password": "password",
        }
        // alert(JSON.stringify(JsonData));
    $.ajax({
        cache: true,
        type: "POST",
        url: getUrl() + "/HotelPMS/LoginCommonServlet",
        //    url: "http://10.168.10.190:8080/HotelPMS/LoginCommonServlet",
        data: {
            "strLoginCommon": JSON.stringify(JsonData)
        },
        async: false,
        error: function(request) {
            alert("获取状态失败，请稍后");
        },
        success: function(data) {
            // alert("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")
            // alert(data);
            var objs = eval(data);
            for (var j = 0; j < objs.length; j++) {
                var aa = new Array();
                // aa[0] = objs[j].id
                // aa[1] = objs[j].userName 
                // aa[2] = objs[j].password
                // aa[3] = objs[j].createTime
                // aa[4] = objs[j].expireTime
                // aa[5] = objs[j].phoneNumber
                // aa[6] = objs[j].email
                aa[7] = objs[j].hotelName
                    // aa[8] = objs[j].hotelGrade
                    // aa[9] = objs[j].loginRole
                    // aa[10] = objs[j].loginRoleLevel
            }
            // document.getElementById("contact").value = aa[5];
            document.getElementById("hotelName").value = aa[7];
        }
    });
    return false;
}

//     // function sendToAccountBook(data) {
//     //     alert(JSON.stringify(data) + "h");
//     //     $.ajax({
//     //         cache: true,
//     //         type: "POST",
//     //         url: "http://admin.wefint.com:8080/Hotel/CoutingBookServlet",
//     //         data: {
//     //             "addCoutingBook": JSON.stringify(data)
//     //         },
//     //         async: false,
//     //         error: function(request) {
//     //             alert("faild");
//     //         },
//     //         success: function(data) {
//     //             alert(data)
//     //             if ("200" == data) { alert("ok") }
//     //         }
//     //     });
//     //     return false;

//     // }
//     $.ajax({
//         cache: true,
//         type: "POST",
//         url: getUrl() + "/HotelPMS/CountingBookServlet",
//         // http: //admin.wefint.com:8080/HotelPMS/RoomSelectServlet
//         data: {
//             "strCountingBook": JSON.stringify(JsonData)

//         },
//         async: false,
//         error: function(request) {
//             alert("获取状态失败，请稍后");
//         },
//         success: function(data) {
//             //alert(data);
//             var obj = JSON.parse(data);
//             //alert(data);
//             var objs = eval(data);

//             for (var j = 0; j < objs.length; j++) {
//                 var aa = new Array();
//                 alert("good");
//                 //  alert(objs[j].roomRoomType);
//                 //  alert(objs[j].roomRoomQuantity);
//                 //  alert(objs[j].roomRoomNumber);
//                 //  alert(objs[j].roomInitialPrice);
//                 //  alert(objs[j].roomCustomPrice);
//                 //  alert(objs[j].loginGrade);
//                 aa[0] = objs[j].hotelName
//                 aa[1] = objs[j].countingType
//                 aa[2] = objs[j].countingMoney
//                 aa[3] = objs[j].countingGoods
//                 aa[4] = objs[j].countingDate
//                     //      aa[2] = objs[j].roomNumber
//                     //     aa[3] = objs[j].roomInitalPrice
//                     //          aa[4] = objs[j].roomSpecialDatePrice
//                     //     alert(aa);
//                 setData(aa);
//             }
//         }
//     });

//     alert("hello")
//     return false;
// }
function loadData(data) {
    //记账收入
    // alert("di0")
    var aa = chazhao(data);
    // alert("记账"+aa)
    document.getElementById("getSum3").innerHTML = aa;
    //  alert("444444444444444444");
    // alert("di1")
//  alert("4446666666666666666666666666664");
    //xianjing
    var xj = chazhao11(data);
    document.getElementById("cash").innerHTML = xj;
    //weixin
    var wx = chazhao12(data);
    // alert("微信"+wx)
    document.getElementById("wx").innerHTML = wx;
    //yinhang
    var yh = chazhao21(data);
    // alert("微信"+wx)
    document.getElementById("yh").innerHTML = yh;
    //zhifubao
    var zf = chazhao13(data);
    document.getElementById("zf").innerHTML = zf;
    //qita
    var qt = chazhao14(data);
    document.getElementById("el").innerHTML = qt;
    //feizhu
    var fz = chazhao15(data);
    document.getElementById("fz").innerHTML = fz;
    //quna
    var qn = chazhao16(data);
    document.getElementById("qn").innerHTML = qn;
    //xiecheng
    var xc = chazhao17(data);
    document.getElementById("xc").innerHTML = xc;
    //yilong
    var yl = chazhao18(data);
    document.getElementById("yl").innerHTML = yl;
    //支出
    // alert("di2")
    var cc = zhichu(data);
    // alert("支出"+cc)
    document.getElementById("setSum").innerHTML = cc;
   
     //房屋收入
      // alert(typeof aa);
    var a1 = Number(xj);
    // alert(a1);
    var b1 = Number(wx);
    // alert(b1);
    var c1 = Number(zf);
    // alert(c1);
    var d1 = Number(qt);
    // alert(d1);
    // alert(a);
    var d2 = a1 + b1 + c1+ d1;
    // alert(d2);
    document.getElementById("getSum").innerHTML = d2;
    //余额
    // alert(typeof aa);
    var a = Number(aa);
    // alert(a);
    var d2 = Number(d2);
    // alert(a);
    var c = Number(cc);
    // alert(a);
    var d = a + d2 - c;
    // alert(typeof d);
    document.getElementById("Sum").innerHTML = d;

}
//记账收入
function chazhao(data) {
    var aa;
    var JsonData = {
            "userName": getCookie('userName'),
            "password": getCookie('password'),
            // "userName": "998",
            // "password": "password",
            "a": data.a,
            "b": data.b,
        }
        // var aa = new Array();
        // alert(JSON.stringify(JsonData));
    $.ajax({
        cache: true,
        type: "POST",
        url: getUrl() + "/HotelPMS/SelectCountingBookNewServlet",
        // url: "http://10.168.10.190:8080/HotelPMS/SelectCountingBookNewServlet",
        data: {
            "strSelectCountingBookNew": JSON.stringify(JsonData)
        },
        async: false,
        error: function(request) {
            alert("添加失败，请联系管理员");
        },
        success: function(data) {
            // alert("1");
            // alert(data);
            // alert("添加成功");

            aa = data;
            // reload();
            // return false;
        }
    });
    return aa;
}

//xianjing
function chazhao11(data) {
    var xj;
    var JsonData = {
            "userName": getCookie('userName'),
            "password": getCookie('password'),
            // "userName": "MTExMTExMTExMTE=",
            // "password": "MTExMTExMTExMTE=",
            "roomNumber": "1",
            "a": data.a,
            "b": data.b,
        }
        // var bb = new Array();
        // alert(JSON.stringify(JsonData));
    $.ajax({
        cache: true,
        type: "POST",
        url: getUrl() + "/HotelPMS/SelectPayWayMoneyServlet",
        // url: "http://10.168.10.190:8080/HotelPMS/SelectPayWayMoneyServlet",
        data: {
            "strPayWayMoney": JSON.stringify(JsonData)
        },
        async: false,
        error: function(request) {
            alert("添加失败，请联系管理员");
        },
        success: function(data) {
            // alert("2");
            // alert(data);
            xj = data;
            // reload();
            // return false;
        }
    });
    return xj;
}
//weixin
function chazhao12(data) {
    var wx;
    var JsonData = {
            "userName": getCookie('userName'),
            "password": getCookie('password'),
            "roomNumber": "1",
            "a": data.a,
            "b": data.b,
        }
        // var bb = new Array();
        // alert(JSON.stringify(JsonData));
    $.ajax({
        cache: true,
        type: "POST",
        url: getUrl() + "/HotelPMS/SelectPayWayWeChatServlet",
        // url: "http://10.168.10.190:8080/HotelPMS/SelectPayWayWeChatServlet",
        data: {
            "strPayWayWeChat": JSON.stringify(JsonData)
        },
        async: false,
        error: function(request) {
            alert("添加失败，请联系管理员");
        },
        success: function(data) {
            // alert("2");
            // alert(data);
            wx = data;
            // reload();
            // return false;
        }
    });
    return wx;
}
//zhifubao
function chazhao13(data) {
    var zf;
    var JsonData = {
            "userName": getCookie('userName'),
            "password": getCookie('password'),
            "roomNumber": "1",
            "a": data.a,
            "b": data.b,
        }
        // var bb = new Array();
        // alert(JSON.stringify(JsonData));
    $.ajax({
        cache: true,
        type: "POST",
        url: getUrl() + "/HotelPMS/SelectPayWayZfbServlet",
        // url: "http://10.168.10.190:8080/HotelPMS/SelectPayWayZfbServlet",
        data: {
            "strPayWayZfb": JSON.stringify(JsonData)
        },
        async: false,
        error: function(request) {
            alert("添加失败，请联系管理员");
        },
        success: function(data) {
            // alert("2");
            // alert(data);
            zf = data;
            // reload();
            // return false;
        }
    });
    return zf;
}
//qita
function chazhao14(data) {
    var qt;
    var JsonData = {
            "userName": getCookie('userName'),
            "password": getCookie('password'),
            "roomNumber": "1",
            "a": data.a,
            "b": data.b,
        }
        // var bb = new Array();
        // alert(JSON.stringify(JsonData));
    $.ajax({
        cache: true,
        type: "POST",
        url: getUrl() + "/HotelPMS/SelectPayWayOtherServlet",
        // url: "http://10.168.10.190:8080/HotelPMS/SelectPayWayOtherServlet",
        data: {
            "strPayWayOther": JSON.stringify(JsonData)
        },
        async: false,
        error: function(request) {
            alert("添加失败，请联系管理员");
        },
        success: function(data) {
            // alert("2");
            // alert(data);
            qt = data;
            // reload();
            // return false;
        }
    });
    return qt;
}
//feizhu
function chazhao15(data) {
    var fz;
    var JsonData = {
            "userName": getCookie('userName'),
            "password": getCookie('password'),
            "roomNumber": "1",
            "a": data.a,
            "b": data.b,
        }
        // var bb = new Array();
        // alert(JSON.stringify(JsonData));
    $.ajax({
        cache: true,
        type: "POST",
        url: getUrl() + "/HotelPMS/SelectSourceFeizhuServlet",
        // url: "http://10.168.10.190:8080/HotelPMS/SelectSourceFeizhuServlet",
        data: {
            "strSourceFeizhu": JSON.stringify(JsonData)
        },
        async: false,
        error: function(request) {
            alert("添加失败，请联系管理员");
        },
        success: function(data) {
            // alert("2");
            // alert(data);
            fz = data;
            // reload();
            // return false;
        }
    });
    return fz;
}
//quna
function chazhao16(data) {
    var qn;
    var JsonData = {
            "userName": getCookie('userName'),
            "password": getCookie('password'),
            "roomNumber": "1",
            "a": data.a,
            "b": data.b,
        }
        // var bb = new Array();
        // alert(JSON.stringify(JsonData));
    $.ajax({
        cache: true,
        type: "POST",
        url: getUrl() + "/HotelPMS/SelectSourceQuNaServlet",
        // url: "http://10.168.10.190:8080/HotelPMS/SelectSourceQuNaServlet",
        data: {
            "strSourceQuNa": JSON.stringify(JsonData)
        },
        async: false,
        error: function(request) {
            alert("添加失败，请联系管理员");
        },
        success: function(data) {
            // alert("2");
            // alert(data);
            qn = data;
            // reload();
            // return false;
        }
    });
    return qn;
}
//xiecheng
function chazhao17(data) {
    var xc;
    var JsonData = {
            "userName": getCookie('userName'),
            "password": getCookie('password'),
            "roomNumber": "1",
            "a": data.a,
            "b": data.b,
        }
        // var bb = new Array();
        // alert(JSON.stringify(JsonData));
    $.ajax({
        cache: true,
        type: "POST",
        url: getUrl() + "/HotelPMS/SelectSourceCtripServlet",
        // url: "http://10.168.10.190:8080/HotelPMS/SelectSourceCtripServlet",
        data: {
            "strSourceCtrip": JSON.stringify(JsonData)
        },
        async: false,
        error: function(request) {
            alert("添加失败，请联系管理员");
        },
        success: function(data) {
            // alert("2");
            // alert(data);
            xc = data;
            // reload();
            // return false;
        }
    });
    return xc;
}
//yilong
function chazhao18(data) {
    var yl;
    var JsonData = {
            "userName": getCookie('userName'),
            "password": getCookie('password'),
            // "roomNumber": "1",
            "a": data.a,
            "b": data.b,
        }
        // var bb = new Array();
        // alert(JSON.stringify(JsonData));
    $.ajax({
        cache: true,
        type: "POST",
        url: getUrl() + "/HotelPMS/SelectSourceYiLongServlet",
        // url: "http://10.168.10.190:8080/HotelPMS/SelectSourceYiLongServlet",
        data: {
            "strSourceYiLong": JSON.stringify(JsonData)
        },
        async: false,
        error: function(request) {
            alert("添加失败，请联系管理员");
        },
        success: function(data) {
            // alert("2");
            // alert(data);
            yl = data;
            // reload();
            // return false;
        }
    });
    return yl;
}


//支出
function zhichu(data) {
    var cc;
    var JsonData = {
            "userName": getCookie('userName'),
            "password": getCookie('password'),
            "a": data.a,
            "b": data.b,
        }
        // alert(JSON.stringify(JsonData));
    $.ajax({
        cache: true,
        type: "POST",
        url: getUrl() + "/HotelPMS/SelectCountBookPayNewServlet",
        // url: "http://10.168.10.190:8080/HotelPMS/SelectCountBookPayNewServlet",
        data: {
            "strSelectCountBookPayNew": JSON.stringify(JsonData)
        },
        async: false,
        error: function(request) {
            alert("添加失败，请联系管理员");
        },
        success: function(data) {
            // alert("3");
            // alert(data);
            cc = data;
            // reload();
            // return false;
        }
    });
    return cc;
}
//记账提交按钮
function formDemo(data) {
    var JsonData = {
            "userName": getCookie('userName'),
            "password": getCookie('password'),
            "hotelName": data.hotelName,
            "countingType": data.countingType,
            "countingMoney": data.countingMoney,
            "countingGoods": data.countingGoods,
            "countingDate": data.countingDate,
            "countingNotes": data.countingNotes,
        }
        // alert(JSON.stringify(JsonData));
    $.ajax({
        cache: true,
        type: "POST",
        url: getUrl() + "/HotelPMS/CountingBookServlet",
        // url: "http://10.168.10.190:8080/HotelPMS/CountingBookServlet",
        data: {
            "strCountingBook": JSON.stringify(JsonData)
        },
        async: false,
        error: function(request) {
            alert("添加失败，请联系管理员");
        },
        success: function(data) {
            // alert(data);
            alert("添加成功");
            reload();
            return false;
        }
    });
    return false;
}
//佣金返回函数
function chazhao20(data) {
    // alert("111111111111111111")
    var JsonData = {
            "userName": getCookie('userName'),
            "password": getCookie('password'),
        }
        // var bb = new Array();
        // alert(JSON.stringify(JsonData));
    $.ajax({
        cache: true,
        type: "POST",
        url: getUrl() + "/HotelPMS/CompensasenSelectServlet",
        // url: "http://10.168.10.190:8080/HotelPMS/CompensasenSelectServlet",
        data: {
            "strSelectCompensasen": JSON.stringify(JsonData)
        },
        async: false,
        error: function(request) {
            alert("添加失败，请联系管理员");
        },
        success: function(data) {
           
            // var obj = JSON.parse(data);
            // alert(data);
            var objs = eval(data);

            for (var j = 0; j < objs.length; j++) {
                var aa = new Array();
                aa[0] = objs[j].compensasenFeiZhuSolid
                aa[1] = objs[j].compensasenYiLongSolid
                aa[2] = objs[j].compensasenXieChengSolid
                aa[3] = objs[j].compensasenQuNaErSolid
        }
        document.getElementById("fz1").innerHTML = aa[0];
        document.getElementById("qn1").innerHTML = aa[1];
        document.getElementById("xc1").innerHTML = aa[2];
        document.getElementById("yl1").innerHTML = aa[3];
        }
    });
    return false;
}
//yinhang
function chazhao21(data) {
    var yh;
    var JsonData = {
            "userName": getCookie('userName'),
            "password": getCookie('password'),
            "roomNumber": "1",
            "a": data.a,
            "b": data.b,
        }
        // var bb = new Array();
        // alert(JSON.stringify(JsonData));
    $.ajax({
        cache: true,
        type: "POST",
        url: getUrl() + "/HotelPMS/SelectPayWayBankServlet",
        // url: "http://10.168.10.190:8080/HotelPMS/SelectPayWayBankServlet",
        data: {
            "strPayWayBank": JSON.stringify(JsonData)
        },
        async: false,
        error: function(request) {
            alert("添加失败，请联系管理员");
        },
        success: function(data) {
            // alert("2");
            // alert(data);
            yh = data;
            // reload();
            // return false;
        }
    });
    return yh;
}