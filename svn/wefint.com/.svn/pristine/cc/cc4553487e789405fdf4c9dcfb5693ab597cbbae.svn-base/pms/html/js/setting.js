function jbsz() {
    //alert("触发点击事件")
    var js = document.getElementById("js");
    var fs = document.getElementById("fs");
    var hs = document.getElementById("hs");
    var bf = document.getElementById("bf");
    js.style.display = "block";
    fs.style.display = "none";
    hs.style.display = "none";
    bf.style.display = "none";
}

function fdsz() {
    //alert("触发点击事件")
    var js = document.getElementById("js");
    var fs = document.getElementById("fs");
    var hs = document.getElementById("hs");
    var bf = document.getElementById("bf");
    js.style.display = "none";
    fs.style.display = "block";
    hs.style.display = "none";
    bf.style.display = "none";
}

function hysz() {
    //alert("触发点击事件")
    var js = document.getElementById("js");
    var fs = document.getElementById("fs");
    var hs = document.getElementById("hs");
    var bf = document.getElementById("bf");
    js.style.display = "none";
    fs.style.display = "none";
    hs.style.display = "block";
    bf.style.display = "none";
}

function bfgn() {
    //alert("触发点击事件")
    var js = document.getElementById("js");
    var fs = document.getElementById("fs");
    var hs = document.getElementById("hs");
    var bf = document.getElementById("bf");
    js.style.display = "none";
    fs.style.display = "none";
    hs.style.display = "none";
    bf.style.display = "block";

}

function btn0() {
    var lxfs = document.getElementById("lxfs2");
    var kzmc = document.getElementById("kzmc2");
    lxfs.style.border = "2px solid #0080ff";
    lxfs.disabled = "";
    kzmc.style.border = "2px solid #0080ff";
    kzmc.disabled = "";
    var xg = document.getElementById("0");
    var qr = document.getElementById("1");
    xg.style.display = "none";
    qr.style.display = "block";
}

function btn1() {
    var zh1 = document.getElementById("zhmc1");
    var lx1 = document.getElementById("lxfs1");
    var kz1 = document.getElementById("kzmc1");
    var zh2 = document.getElementById("zhmc2");
    var lx2 = document.getElementById("lxfs2");
    var kz2 = document.getElementById("kzmc2");

    zh1.value = zh2.value;
    lx1.value = lx2.value;
    kz1.value = kz2.value;
    /** var user ={
				"zhmc":zhmc,
			    "fdid":fdid,
			    "fdpsw":fdpsw,
			    "fdname":fdname,
			    "fdnumber":fdnumber
			};
		$.ajax({
			cache : true,
			type : "post",
			url : getUrl() + "/Hotel/LoginServlet",
			data : {
				"strLogin" : JSON.stringify(user)
			},
			async : false,
			error : function(request) {
				alert("faild");
			},
			success : function(list) {
				alert("传值成功 ");
				var obj = JSON.parse(list);
				$.each(obj,function(idx,item){    
				     //输出
				     alert(item.VIPSettingID+"哈哈"+item.VIPSettingLevel);
				  })
			}
		});
		return false;**/
    var js = document.getElementById("js");
    js.style.display = "none";
}

function btn2() {
    var id = document.getElementById("id");
    var psw = document.getElementById("psw");
    var name = document.getElementById("name");
    var number = document.getElementById("number");
    var zh1 = document.getElementById("zhmc1");
    var zhmc = zh1.value;
    var fdid = id.value;
    var fdpsw = psw.value;
    var fdname = name.value;
    var fdnumber = number.value;
    var user = {
        "zhmc": zhmc,
        "fdid": fdid,
        "fdpsw": fdpsw,
        "fdname": fdname,
        "fdnumber": fdnumber
    };
    /**$.ajax({
    	cache : true,
    	type : "post",
    	url : getUrl() + "/Hotel/LoginServlet",
    	data : {
    		"strLogin" : JSON.stringify(user)
    	},
    	async : false,
    	error : function(request) {
    		alert("faild");
    	},
    	success : function(list) {
    		alert("传值成功 ");
    		var obj = JSON.parse(list);
    		$.each(obj,function(idx,item){    
    		     //输出
    		     alert(item.VIPSettingID+"哈哈"+item.VIPSettingLevel);
    		  })
    	}
    });
    return false;**/
    var fs = document.getElementById("fs");
    fs.style.display = "none";
}

function hf1() {
    var hf = document.getElementById("hf1");
    var bf = document.getElementById("bf1");
    hf.style.display = "block";
    bf.style.display = "none";
}

function bf1() {
    var hf = document.getElementById("hf1");
    var bf = document.getElementById("bf1");
    hf.style.display = "none";
    bf.style.display = "block";
}