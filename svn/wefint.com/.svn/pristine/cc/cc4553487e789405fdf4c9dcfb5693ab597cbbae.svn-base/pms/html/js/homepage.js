function login(){
	window.location.href="./login.html";
}
function zhuce(){
	window.location.href="./zhuce.html";
}
