function memberRegister(data) {
    // alert(data + "get here");
    var obj0 = JSON.parse(data);
    // alert(obj0.loginAccountPassword);
    // alert(obj0.loginAccountPassword2);

    if (obj0.loginAccountPassword != obj0.loginAccountPassword2) return "400";
    var base = new Base64();
    var encodeStr = base.encode(obj0.loginAccountNumber);
    var encodeStr1 = base.encode(obj0.loginAccountPassword);
    var user = {
        "loginAccountNumber": encodeStr,
        "loginAccountPassword": encodeStr1,
        "loginHotelName": obj0.loginHotelName,
        "loginLocation": obj0.loginLocation,
        "loginPhoneNumber": obj0.loginPhoneNumber
    }

    //  alert(JSON.stringify(user));
    $.ajax({
        cache: true,
        type: "POST",
        url: getUrl() + "/Hotel/LoginServlet",
        data: {
            "register": JSON.stringify(user)
        },
        async: false,
        error: function(request) {
            alert("注册失败，请稍后再试");
        },
        success: function(data) {
            //    alert(data);
            if (data == "800") {
                alert("用户名重复请更换！");
            }
            if (data == "200") {
                alert("注册成功请登陆");
                window.location.href = "./login.html";
                // window.location.href = "./mainPannel.html";
            }
            return false;
        }
    });
    return false;
}
/* 将register.html页面的script提出了到这个js里面 */
var code;

function createCode() {
    code = "";
    var codeLength = 4;
    var checkCode = document.getElementById("code");
    var random = new Array(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
        'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z');
    for (var i = 0; i < codeLength; i++) {
        var index = Math.floor(Math.random() * 36);
        code += random[index];
    }
    document.getElementById("code").value = code;
}

function validate() {

    var inputCode = document.getElementById("checkcode").value.toUpperCase();
    // alert("hhe" + inputCode);
    if (inputCode.length <= 0) {
        return false;
    } else if (inputCode != code) {
        alert("验证码错误!");
        createCode();
        document.getElementById("checkcode").value = "";
        return false;
    }
    return true;
}