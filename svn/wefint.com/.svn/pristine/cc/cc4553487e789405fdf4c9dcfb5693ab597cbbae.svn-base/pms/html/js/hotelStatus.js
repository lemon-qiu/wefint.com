//获得房屋状态

function getNowRoomStatus() {
    var beginDate = getNowDate();
    var a1 = document.getElementById("nowTimeChoose");
    a1.value = beginDate;
    // setTableHeaderAuto();getRooms();

    // setTableHeaderAuto();
    setTableHeader(1, getData(beginDate));
    getRooms(beginDate);
}

function getRooms(date) {
    //  alert("dd")
    var beginDate = date;
    // var a1 = document.getElementById("nowTimeChoose");
    // a1.value = beginDate;
    //  alert(getData(beginDate)[29])
    $.ajax({
        cache: true,
        type: "POST",
        url: "http://localhost:3000/roomStatus/queryByDateQuantum",
        data: {
            "userName": getCookie('userName'),
            "password": getCookie('password'),
            "beginDate": getNowDate(),
            "endDate": getData(beginDate)[30],
        },
        async: false,
        error: function(request) {
            alert("获取状态失败，请稍后1");
        },
        success: function(data) {
            alert(data);
            var obj = JSON.parse(data);
            // alert(obj.code);
            // alert(obj.roomPropertyLength);

            // alert(obj.roomProperty);
            // alert(obj.roomStatus);
            var objs = eval(obj.roomProperty);
            var objs1 = eval(obj.roomStatus);
            for (var j = 0; j < objs.length; j++) {
                var aa = new Array();
                aa[0] = objs[j].roomName
                aa[1] = objs[j].roomNumber
                    //   alert(aa);
                    //设置左边表格
                setLeft(aa);
                // setTable0(1, getStatus(getCookie('userName'), getCookie('password'), aa[1], nowNowDate), aa[1], getData(nowNowDate));
                setMain(objs[j].Id, j, objs1, getData(beginDate));
            }
        }
    });
    return false;
}

function getNowDate() {
    //    alert("dd2")
    var now = new Date();
    var year = now.getFullYear(); //年   
    var month = now.getMonth() + 1; //月   
    var day = now.getDate(); //日
    var nowNowDate = year + "-" + month + "-" + day;
    // alert(getStatus("", "", aa[1], nowNowDate).length);
    return nowNowDate;
}
// 按照传入时间生成30天表格
function setLeft(getData) {
    setLeftTable(1, getData);
}

function setMain(roomId, j, roomStatus, date) {
    //  alert("roomProperty.length: " + roomProperty.length)
    //alert("data.roomId: " + data.roomId)
    // for (var j = 0; j < roomProperty.length; j++) {
    var bb = new Array();
    //  alert(roomStatus)
    if (roomStatus != "") {
        alert("gethere")
        if (roomId == roomStatus[j].roomId) {
            for (var i = 0; i < date.length; i++) {
                if (date[i] == roomStatus[j].hasStayDate.substring(0, 10)) {
                    //   alert(data[j].hasStayDate.substring(0, 10))
                    bb[i] = "1"
                } else {
                    bb[i] = "0"
                }
            }
        }
    } else {
        for (var i = 0; i < date.length; i++) {
            bb[i] = "0"
        }
    }
    // setTable(1, bb);
    setTable0(1, bb, roomId, date);
    // }
    // setLeftTable(1, getData);
}

//设置左边表格
function setLeftTable(trLineNumber, tdData) {
    var _table = document.getElementById("table1");
    // _table.innerHTML = ""
    var _row;
    var _cell;
    for (var i = 0; i < trLineNumber; i++) {
        _row = document.createElement("tr");
        document.getElementById("table1").appendChild(_row);
        for (var j = 0; j < tdData.length; j++) {
            _cell = document.createElement("td");
            // _cell.onclick = function() { getColumnDetail(this) }; //为每个单元格增加单击事件
            _cell.innerText = tdData[j];
            _row.appendChild(_cell);
        }
        _row.appendChild(_cell);
    }
}

//设置右边表格
function setTable0(trLineNumber, tdData, j, date) {
    alert(tdData)
    var _table = document.getElementById("table2");
    // _table.innerHTML = ""
    var _row;
    var _cell;
    for (var i = 0; i < trLineNumber; i++) {
        _row = document.createElement("tr");
        document.getElementById("table2").appendChild(_row);
        _row.id = j;
        for (var j = 0; j < tdData.length; j++) {
            _cell = document.createElement("td");
            _cell.onclick = function() { getColumnDetail(this) }; //为每个单元格增加单击事件
            _cell.id = date[j];

            var aData = new Array();
            aData = tdData[j].split("-");

            if (aData[0] == "1") {
                _cell.innerText = "已预定\n" + aData[1];
                _cell.bgColor = "#ccc";
            } else if (aData[0] == "2") {
                _cell.innerText = "已入住\n" + aData[1];;
                _cell.bgColor = "#5FB878";
            }
            // _cell.innerText = tdData[j];
            _row.appendChild(_cell);
        }
        _row.appendChild(_cell);
    }
}


function m(a) {
    layui.laydate(a);
}
layui.use('laydate', function() {
    var laydate = layui.laydate;
});


function getColumnDetail(cell) {

    setCookie("Date", cell.id);
    setCookie("roomNumber", cell.parentNode.id);

    // alert(cell.innerHTML)
    var aData = new Array();
    aData = cell.innerHTML.split("<br>");
    if (aData[0] == "已预定") {
        layer.open({
            type: 1,
            // skin: 'layui-layer-rim', //加上边框
            area: ['950px', '500px'], //宽高
            content: '<div><iframe src="./booking.html" width="950px" height="450px" scrolling="no" frameborder="0"name="framelayer"> </iframe></div>'
        });
    } else if (aData[0] == "已入住") {

        layer.open({
            type: 1,
            // skin: 'layui-layer-rim', //加上边框
            area: ['950px', '500px'], //宽高
            content: '<div><iframe src="./checkin.html" width="950px" height="450px" scrolling="no" frameborder="0"name="framelayer"> </iframe></div>'
        });

        alert("已入住")
    } else
        layer.open({
            type: 1,
            // skin: 'layui-layer-rim', //加上边框
            area: ['950px', '500px'], //宽高
            content: '<div><iframe src="./hotelStatusSetupLayer.html" width="950px" height="450px" scrolling="no" frameborder="0"name="framelayer"> </iframe></div>'
        });
}
// <!--trLineNumber为动态表格行数，tdData为动态表格每行单元格的数据，数据类型为数组-->
function setTable(trLineNumber, tdData) {
    //  alert(tdData)
    var _table = document.getElementById("table2");
    var _row;
    var _cell;
    for (var i = 0; i < trLineNumber; i++) {
        _row = document.createElement("tr");
        document.getElementById("table2").appendChild(_row);
        //  _row.id=i;
        for (var j = 0; j < tdData.length; j++) {
            _cell = document.createElement("td");
            _cell.onclick = function() { getColumnDetail(this) }; //为每个单元格增加单击事件
            _cell.innerText = tdData[j];
            _row.appendChild(_cell);
        }
    }
}

function setTableHeader(trLineNumber, tdData) {
    var _table = document.getElementById("table2");
    _table.innerHTML = ""
    var _row;
    var _cell;
    for (var i = 0; i < trLineNumber; i++) {
        _row = document.createElement("tr");
        document.getElementById("table2").appendChild(_row);
        for (var j = 0; j < tdData.length; j++) {
            _cell = document.createElement("td");
            // _cell.onclick = function() { getColumnDetail(this) }; //为每个单元格增加单击事件
            _cell.innerText = tdData[j];
            _row.appendChild(_cell);
        }

    }
}

function setTableHeaderAuto() {
    // myDate.getDate();
    var myArray = new Array();
    for (var i = 0; i < 31; i++) {
        // alert(i);
        var now = new Date();
        var show_day = new Array('日', '一', '二', '三', '四', '五', '六');
        now.setDate(now.getDate() + i);
        var month = now.getMonth() + 1; //月   
        var day = now.getDate(); //日
        var xinqi = now.getDay(); //星期
        myArray[i] = month + "-" + day + "-" + show_day[xinqi];
        // myArray[i] = now;
    }
    // myArray[0] =
    // column.style.color = "blue"; //将被点击的单元格设置为蓝色
    setTableHeader(1, myArray);
}

function getData(getData) {
    var myArray = new Array();
    for (var i = 0; i < 31; i++) {
        var curDate = new Date(getData);
        var show_day = new Array('日', '一', '二', '三', '四', '五', '六');
        curDate.setDate(curDate.getDate() + i);
        var year = curDate.getFullYear();
        var month = curDate.getMonth() + 1; //月 
        month = month < 10 ? '0' + month : month;
        var day = curDate.getDate(); //日
        day = day < 10 ? ('0' + day) : day;
        var xinqi = curDate.getDay(); //星期
        myArray[i] = year + "-" + month + "-" + day;
    }
    return myArray
}

// 按照传入时间生成30天表格
function setData(getData) {
    var myArray = new Array();
    for (var i = 0; i < 31; i++) {
        var curDate = new Date(getData);
        var show_day = new Array('日', '一', '二', '三', '四', '五', '六');
        curDate.setDate(curDate.getDate() + i);
        var month = curDate.getMonth() + 1; //月 
        var day = curDate.getDate(); //日
        var xinqi = curDate.getDay(); //星期
        myArray[i] = month + "-" + day + "-" + show_day[xinqi];
        // myArray[i] = month + "-" + day;
    }
    setTableHeader(1, myArray);
}
//   获取上一个月
function getPreMonth(date) {
    var arr = date.split('-');
    var year = arr[0]; //获取当前日期的年份  
    var month = arr[1]; //获取当前日期的月份  
    var day = arr[2]; //获取当前日期的日  
    // var xinqi = arr[3]; //获取当前日期的星期
    var days = new Date(year, month, 0);
    days = days.getDate(); //获取当前日期中月的天数  

    var year2 = year;
    var month2 = parseInt(month) - 1;
    if (month2 == 0) {
        year2 = parseInt(year2) - 1;
        month2 = 12;
    }
    var day2 = day;
    var days2 = new Date(year2, month2, 0);
    days2 = days2.getDate();
    if (day2 > days2) {
        day2 = days2;
    }
    if (month2 < 10) {
        month2 = '0' + month2;
    }
    var t2 = year2 + '-' + month2 + '-' + day2;
    return t2;
}

//  获取下一个月 

function getNextMonth(date) {
    var arr = date.split('-');
    var year = arr[0]; //获取当前日期的年份  
    var month = arr[1]; //获取当前日期的月份  
    var day = arr[2]; //获取当前日期的日  
    var days = new Date(year, month, 0);
    days = days.getDate(); //获取当前日期中的月的天数  
    var year2 = year;
    var month2 = parseInt(month) + 1;
    if (month2 == 13) {
        year2 = parseInt(year2) + 1;
        month2 = 1;
    }
    var day2 = day;
    var days2 = new Date(year2, month2, 0);
    days2 = days2.getDate();
    if (day2 > days2) {
        day2 = days2;
    }
    if (month2 < 10) {
        month2 = '0' + month2;
    }
    var t2 = year2 + '-' + month2 + '-' + day2;
    return t2;
}


//左按钮
function leftChoose() {
    var a1 = document.getElementById("nowTimeChoose");
    a1.value = getPreMonth(a1.value)
    document.getElementById("table1").innerHTML = "";
    document.getElementById("table2").innerHTML = "";
    setTableHeader(1, getData(a1.value));
    getRooms(a1.value)
        // setData(a1.value);
        // buttonGetRooms(a1.value);
}

//中按钮
function nowTimeChoose(e) {
    var a1 = document.getElementById("nowTimeChoose");
    setData(a1.value);
    buttonGetRooms(a1.value);
}
//右按钮
function rightChoose() {
    var a1 = document.getElementById("nowTimeChoose");
    a1.value = getNextMonth(a1.value)
    document.getElementById("table1").innerHTML = "";
    document.getElementById("table2").innerHTML = "";
    setTableHeader(1, getData(a1.value));
    getRooms(a1.value)
        // setData(a1.value);
        // buttonGetRooms(a1.value);
}